from project.stack import Stack

stack = Stack()

stack.push("alex")
stack.push("aex")
stack.push("x")
stack.push("ew")

print(stack)