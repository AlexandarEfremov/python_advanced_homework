from project.teacher import Teacher

teacher = Teacher()
print(teacher.sleep())