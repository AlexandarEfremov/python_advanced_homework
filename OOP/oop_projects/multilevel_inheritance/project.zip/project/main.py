from project.sports_car import SportsCar

car = SportsCar()

print(car.race())
print(car.drive())
print(car.move())
