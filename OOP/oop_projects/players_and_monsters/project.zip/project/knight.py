from project.hero import Hero


class Knight(Hero):
    pass
