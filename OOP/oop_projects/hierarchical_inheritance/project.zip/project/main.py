from project.cat import Cat
from project.dog import Dog

dog = Dog()
cat = Cat()

print(dog.eat())
print(cat.meow())